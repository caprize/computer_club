from django.contrib import admin





from .models import *
admin.site.register(User)
admin.site.register(Payment)
admin.site.register(OrderTable)
admin.site.register(Computer)
admin.site.register(ComputerClub)
admin.site.register(Engineer)
admin.site.register(Breakage)
# Register your models here.
